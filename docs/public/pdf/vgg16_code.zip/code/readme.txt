Please place the Caltech 101 dataset in the path `./dataset/101_ObjectCategories` to run the code.

You can download the dataset for free on https://data.caltech.edu/records/mzrjq-6wc02